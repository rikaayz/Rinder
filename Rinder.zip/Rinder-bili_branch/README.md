# Rinder Project Software Engineering

# By Software Engineering group of
# Immanuel Billy Christian S - 2540132723
# Vivian Dwitama - 2501962870
# Febri Fransisca Djaya - 2540129193
# Khumaira Malik Anabil - 2540132080
# Rika Zakiyyah - 2540134994
