package rinder.com;

public class ForgotPassActivity {
}
